var mysql = require('mysql');
// Create MySQL connection pool
var pool = mysql.createPool({
    connectionLimit : 100,
    host            : process.env.HOST,
    user            : process.env.USER,
    password        : process.env.PASS,
    database        : process.env.DATA
});

// Pass all MySQL queries through this function
function sqlQuery(q, fn){
    var pool = require('./controllers').pool;
    pool.query(q, function(err, rows) {
        fn(rows);
    });
}

exports.pool = pool; // Export MySQL connection pool
exports.sqlQuery = sqlQuery; // Export MySQL query function
